package com.example.kanbanosAPI.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class JwtTokenUtil {

    private final String secretKey = "secretkey";

    public String generateToken(String username) throws NoSuchAlgorithmException {
        String header = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
        String payload = "{\"sub\":\"" + username + "\"}";

        String encodedHeader = Base64.getUrlEncoder().encodeToString(header.getBytes(StandardCharsets.UTF_8));
        String encodedPayload = Base64.getUrlEncoder().encodeToString(payload.getBytes(StandardCharsets.UTF_8));

        String dataToSign = encodedHeader + "." + encodedPayload;
        String signature = hmacSha256(dataToSign, secretKey);

        return encodedHeader + "." + encodedPayload + "." + signature;
    }

    private String hmacSha256(String data, String key) throws NoSuchAlgorithmException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] hash = sha256.digest((data + key).getBytes(StandardCharsets.UTF_8));
        return Base64.getUrlEncoder().encodeToString(hash);
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        JwtTokenUtil jwtTokenUtil = new JwtTokenUtil();
        String token = jwtTokenUtil.generateToken("usuario_exemplo");
        System.out.println("Token JWT: " + token);
    }
}
