package com.example.kanbanosAPI.service;

import com.example.kanbanosAPI.model.Tarefa;
import com.example.kanbanosAPI.model.Prioridade;
import com.example.kanbanosAPI.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TarefaService {

    private final TarefaRepository tarefaRepository;

    @Autowired
    public TarefaService(TarefaRepository tarefaRepository) {
        this.tarefaRepository = tarefaRepository;
    }

    // Criar nova tarefa
    public Tarefa criarTarefa(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    // Listar todas as tarefas
    public List<Tarefa> listarTarefas() {
        return tarefaRepository.findAll();
    }

    // Buscar tarefa por ID
    public Optional<Tarefa> buscarTarefaPorId(Long id) {
        return tarefaRepository.findById(id);
    }

    // Mover tarefa para próxima coluna
    public Tarefa moverTarefa(Long id) {
        Tarefa tarefa = tarefaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Tarefa não encontrada"));

        switch (tarefa.getStatus()) {
            case A_FAZER:
                tarefa.setStatus(Tarefa.Status.EM_PROGRESSO);
                break;
            case EM_PROGRESSO:
                tarefa.setStatus(Tarefa.Status.CONCLUIDO);
                break;
            default:
                throw new IllegalArgumentException("Tarefa já concluída");
        }

        return tarefaRepository.save(tarefa);
    }

    // Atualizar tarefa
    public Tarefa atualizarTarefa(Long id, Tarefa tarefaAtualizada) {
        Tarefa tarefaExistente = tarefaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Tarefa não encontrada"));

        tarefaExistente.setTitle(tarefaAtualizada.getTitle());
        tarefaExistente.setDescription(tarefaAtualizada.getDescription());
        tarefaExistente.setPriority(tarefaAtualizada.getPriority());
        tarefaExistente.setDueDate(tarefaAtualizada.getDueDate());

        return tarefaRepository.save(tarefaExistente);
    }

    // Excluir tarefa
    public void excluirTarefa(Long id) {
        tarefaRepository.deleteById(id);
    }
}
