package com.example.kanbanosAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanbanosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanbanosApiApplication.class, args);
	}
}
